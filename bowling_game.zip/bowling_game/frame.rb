class Frame
  
  def initialize
    @rolls = []
  end
  
  def roll(pins)
    @rolls << pins
  end
  
  def first
    @rolls.first
  end
  
  def second
    @rolls[1]
  end
  
  def spare?
    return false unless second
    first + second == 10
  end
  
  def strike?
    first == 10
  end
  
  def sum_of_rolls
    @rolls.inject {|sum, n| sum + n}
  end
  
end