require File.expand_path(File.join(File.dirname(__FILE__), "frame"))

describe Frame do
  
  let(:frame) { Frame.new }
  
  it "can store one roll" do
    frame.roll(1)
    frame.first.should == 1
  end
  
  it "can store two rolls" do
    frame.roll(1)
    frame.roll(2)
    frame.first.should == 1
    frame.second.should == 2
  end
  
  it "should be a spare if first roll and 2nd roll == 10" do
    frame.roll(6)
    frame.roll(4)
    frame.should be_spare
  end

  it "should not be a spare if there is only one roll" do
    frame.roll(6)
    frame.should_not be_spare    
  end
  
  it "should not be a spare if 1st and 2nd roll do not add up to ten" do
    frame.roll(6)
    frame.roll(1)
    frame.should_not be_spare
  end

  it "should know the sum of the rolls for the frame" do
    frame.roll(6)
    frame.sum_of_rolls.should == 6
    frame.roll(1)
    frame.sum_of_rolls.should == 7
  end
  
  it "should be a strike if the first roll == 10" do
    frame.roll(10)
    frame.should be_strike
  end
  
end