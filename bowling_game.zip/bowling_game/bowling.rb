# bowling.rb
require File.expand_path(File.join(File.dirname(__FILE__), "frame"))

class Bowling
  
  def initialize
    @score = 0
    @frames = []
  end
  
  def roll(pins)
    if @frames.last.nil? or @frames.last.second or @frames.last.strike?
      @frames << Frame.new
    end
    @frames.last.roll(pins)
  end
  
  def score
    result = 0
    @frames.each_with_index do |frame, idx|
      if idx > 0
        if @frames[idx - 1].strike?
          result += frame.sum_of_rolls
        elsif @frames[idx - 1].spare?
          result += frame.first
        end
      end
      
      result += frame.sum_of_rolls
      
    end
    result
  end
  
end